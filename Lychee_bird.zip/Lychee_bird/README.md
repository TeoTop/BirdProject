BirdProject
===========

Projet d'étude pratique. Utilisation de raspberry pi afin de prendre des oiseaux en photo.
