### Everywhere
| Key | Action |
|:-----------|:------------|
| `enter` | Confirm Dialog |
| `u` | Upload photo |
| `esc` | Close/Back |  
| `cmd`+`up` | Close/Back | 

### Photoview
| Key | Action |
|:-----------|:------------|
| `s` | Star photo |  
| `i` | Show information |  
| `cmd`+`backspace` | Delete photo  
| `left` | Previous photo  
| `right` | Next photo  